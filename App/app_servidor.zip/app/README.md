# APP_TFG
Aplicación Android para monitorización de balizas y bomberos

Mejoras a realizar o fallos:
- Pestaña Datos en Tiempo Real: cuando hay muchas balizas, ¿se ven las cardview de todas las balizas? Usar ScrollView para poder bajar la pantalla
- ¿Qué pestaña o pantalla poner para cuando iniciamos la app?
- Sacar más datos en pantalla como RSSI, fecha, etc.
