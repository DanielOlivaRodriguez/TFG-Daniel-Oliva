package com.example.tfg.Fragments;


import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tfg.Adapters.MyAdapter2;
import com.example.tfg.Datos.Balizas;
import com.example.tfg.R;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
/*Fragment para la pestaña Datos Históricos*/
public class DatosHistoricosFragment extends Fragment implements Response.Listener<JSONObject>, Response.ErrorListener {
    /*Declaración de variables, contexto, objetos, request, etc*/

    private LineChart mChart1, mChart2;

    View view;

    private static Context context =null;

    List<Balizas> balizalist;

    TextView textViewhora, textViewNBalizas, textTit1, textTit2, textTit3;
    Button btn_refrescar;
    ProgressDialog progreso;

    private RecyclerView rv;
    private RecyclerView.LayoutManager mLayoutManager;

    RequestQueue request;
    JsonObjectRequest jsonObjectRequest;

    String temperatura,nivelco, hora, balizaid, rssi, fuego, comentario, NBalizas, nBalizas, dx, dy,balizaidB, dxB, dyB;
    int intNbalizas;

    /*construtor de la clase*/
    public DatosHistoricosFragment() {
        // Required empty public constructor
    }

    /*crea y devuelve la jerarquía de vistas asociada con el fragmento*/
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_datos_historicos, container, false);

        /*enlazo las vistas con las gráficas*/
        mChart1 = view.findViewById(R.id.chart1);
        mChart2 = view.findViewById(R.id.chart2);
        /*animación de las gráficas*/
        mChart1.animateX(1000);
        mChart2.animateX(1000);
        /*enlazo la vista del RecyclerView*/
        rv = view.findViewById(R.id.rv2);
        /*esta configuración mejora el desempeño y se usa cuando el tamaño del RecyclerView no cambia*/
        rv.setHasFixedSize(true);
        /*Uso de Linear Layout Manager*/
        mLayoutManager = new LinearLayoutManager(getContext());
        rv.setLayoutManager(mLayoutManager);
        /*Como estoy en un Fragment no puedo pasar this y necesito coger el contexto de la actividad*/
        context = getActivity();
        /*creación de un nuevo ArrayList */
        balizalist = new ArrayList<>();
        /*enlazo las vistas y botón*/
        textTit1 = view.findViewById(R.id.textTit1);
        textTit2 = view.findViewById(R.id.textTit2);
        textTit3 = view.findViewById(R.id.textTit3);
        textViewhora = view.findViewById(R.id.textHoraGraph);
        textViewNBalizas = view.findViewById(R.id.NBalizasGraph);
        btn_refrescar = view.findViewById(R.id.btn_refescarGraph);
        /*Instancia el RequestQuere */
        request = Volley.newRequestQueue(getContext());

        /*Cuando se pulsa el botón refrescar se llama al método cargarWebService y limpia las vistas
         del RecyclerView para que no se acumulen cada vez que pulsamos el botón*/
        btn_refrescar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                balizalist.clear();
                //Validación del campo de texto del número de balizas
                if (textViewNBalizas.getText().toString().isEmpty()){
                    Toast.makeText(getContext()," Introduce un número de baliza válido",Toast.LENGTH_SHORT).show();
                }
                else {
                    /*Extraigo el texto escrito por el usuario (nº de balizas) y lo paso a integer (numero)*/
                    NBalizas = textViewNBalizas.getText().toString();
                    intNbalizas =Integer.parseInt(NBalizas);
                    /*llamada al método de conexión con la base de datos*/
                    cargarWebService();
                    /*llamada al método para cerrar el teclado*/
                    cerrarteclado();
                    /*poner texto refrescar en el botón y el hint*/
                    btn_refrescar.setText("Refrescar");
                    textViewNBalizas.setHint("Introduce el número de baliza y pulse REFRESCAR");
                }
            }
        });

        // Inflate the layout for this fragment
        return view;
    }

    /*método que se conecta a la base de datos*/
    private void cargarWebService() {
        /*Mensaje al pulsar el botón*/
        progreso = new ProgressDialog(getContext());
        progreso.setMessage("refrescando...");
        /*abrimos el mensaje de cargando*/
        progreso.show();
        /*URL del archivo PHP que nos devuelve el JSON de los datos pedidos*/
        String url = "https://tfgbomberos.000webhostapp.com/baliza_graph.php?n="+NBalizas;
        /*Solicitud para recuperar un JsonObject*/
        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url,null,this,this);
        request.add(jsonObjectRequest);
    }

    /*método fallo con la petición*/
    @Override
    public void onErrorResponse(VolleyError error) {
        /*cerramos el mensaje de cargando*/
        progreso.hide();
        /*mensaje con error*/
        Toast.makeText(getContext(), "Error de conexión" + error.toString(), Toast.LENGTH_SHORT).show();
        Log.i("Error", error.toString());
    }

    /*método respuesta de la petición*/
    @Override
    public void onResponse(JSONObject response) {
        /*cerramos el mensaje de cargando*/
        progreso.hide();

        /*mensaje toast de conexión realizada*/
        Toast.makeText(getContext(), "Conexión establecida", Toast.LENGTH_SHORT).show();

        /*Llamada al constructor de la clase Balizas*/
        Balizas balizas = new Balizas(hora, temperatura, nivelco, balizaid, rssi, fuego, comentario, nBalizas, dx, dy, balizaidB, dxB, dyB);

        /*creación de un json tipo array*/
        JSONArray json = response.optJSONArray("baliza");

        /*inicialización del jsonOBject*/
        JSONObject jsonObject=null;

        /*definición de ArrayList para las gráficas*/
        ArrayList<Entry> yVals1 = new ArrayList<>();
        ArrayList<Entry> yVals2 = new ArrayList<>();

        try {
            /*bucle para sacar los datos del json*/
            for ( int i = 0; i < json.length(); i++){
                jsonObject = json.getJSONObject(i);

                /*set de los datos del json*/
                balizas.setTemperatura(jsonObject.optString("temperatura"));
                balizas.setNivelco(jsonObject.optString("nivelco"));
                balizas.setHora(jsonObject.optString("hora"));

                /*get de los datos del json*/
                temperatura = balizas.getTemperatura();
                nivelco = balizas.getNivelco();
                hora = balizas.getHora();

                /*añadir a las listas los datos extraídos del json*/
                yVals1.add(new Entry(i, Float.parseFloat(temperatura)));
                yVals2.add(new Entry(i, Float.parseFloat(nivelco)));

                /*añadir a la lista balizalist los datos extraídos del json*/
                balizalist.add(new Balizas(hora, temperatura, nivelco, balizaid, rssi, fuego, comentario, nBalizas, dx, dy, balizaidB, dxB, dyB));

            }
            /*Actualizar el campo de texto  de hora, temperaturas, niveles de co y lista y hacerlos visibles*/
            textViewhora.setText("Hora últimos datos: "+hora);
            textViewhora.setVisibility(View.VISIBLE);
            textTit1.setText("Temperaturas de la Baliza "+NBalizas);
            textTit1.setVisibility(View.VISIBLE);
            textTit2.setText("Niveles de CO de la Baliza "+NBalizas);
            textTit2.setVisibility(View.VISIBLE);
            textTit3.setText("Lista de datos de la Baliza "+NBalizas);
            textTit3.setVisibility(View.VISIBLE);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        /*Graficación de los datos y características de las gráficas*/
        LineDataSet set1;
        set1 = new LineDataSet(yVals1, "Temperatura en ºC");
        set1.setColor(Color.RED);
        set1.setLineWidth(3f);
        LineData data = new LineData(set1);
        mChart1.setData(data);
        mChart1.invalidate();
        YAxis yAxis;
        yAxis = mChart1.getAxisLeft();
        yAxis.setAxisMaximum(155f);
        yAxis.setAxisMinimum(0f);
        XAxis xAxis;
        xAxis = mChart1.getXAxis();
        xAxis.setAxisMinimum(0f);
        xAxis.setGranularity(1f);
        data.setValueTextSize(9f);
        mChart1.setVisibility(View.VISIBLE);

        LineDataSet set2;
        set2 = new LineDataSet(yVals2, "Nivel CO en %");
        set2.setColor(Color.RED);
        set2.setLineWidth(3f);
        LineData data2 = new LineData(set2);
        mChart2.setData(data2);
        mChart2.invalidate();
        YAxis yAxis2;
        yAxis2 = mChart2.getAxisLeft();
        yAxis2.setAxisMaximum(100f);
        yAxis2.setAxisMinimum(0f);
        XAxis xAxis2;
        xAxis2 = mChart2.getXAxis();
        xAxis2.setAxisMinimum(0f);
        data2.setValueTextSize(9f);
        xAxis2.setGranularity(1f);
        mChart2.setVisibility(View.VISIBLE);

        /*Pasamos el adaptader correspondiente a esta pestaña y mostramos las vistas del reciclerview*/
        MyAdapter2 adapter = new MyAdapter2(getContext(), balizalist);
        rv.setAdapter(adapter);
        rv.setVisibility(View.VISIBLE);
    }
    //Función para cerrar el teclado
    private void cerrarteclado(){
        View view = getActivity().getCurrentFocus();
        if (view !=null){
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(getContext().INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
