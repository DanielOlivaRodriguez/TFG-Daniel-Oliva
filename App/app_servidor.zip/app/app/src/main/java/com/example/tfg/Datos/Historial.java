package com.example.tfg.Datos;

public class Historial {

    //Títulos de las columnas de la BBDD
    private String id_bombero;
    private String id_dispositivo;
    private String fecha;

    //Constructor de clase
    public Historial(String id_bombero, String id_dispositivo, String fecha) {
        this.id_bombero = id_bombero;
        this.id_dispositivo = id_dispositivo;
        this.fecha = fecha;

    }

    public String getId_bombero() {
        return id_bombero;
    }
    public void setId_bombero(String id_bombero) {
        this.id_bombero = id_bombero;
    }

    public String getid_dispositivo() {
        return id_dispositivo;
    }
    public void setid_dispositivo(String id_dispositivo) { this.id_dispositivo = id_dispositivo;}

    public String getfecha() {
        return fecha;
    }
    public void setfecha(String fecha) {
        this.fecha = fecha;
    }

}
