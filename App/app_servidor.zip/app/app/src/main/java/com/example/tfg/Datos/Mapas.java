package com.example.tfg.Datos;
/*clase con métodos get and set para mostrar los datos de los mapas*/
public class Mapas {
    /*declaraciones de los datos a extraer de cada mapa*/
    private String id;
    private String CoorX;
    private String CoorY;

    /*Constructor de la clase Mapas*/
    public Mapas(String id, String coorX, String coorY) {
        this.id = id;
        CoorX = coorX;
        CoorY = coorY;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCoorX() {
        return CoorX;
    }

    public void setCoorX(String coorX) {
        CoorX = coorX;
    }

    public String getCoorY() {
        return CoorY;
    }

    public void setCoorY(String coorY) {
        CoorY = coorY;
    }
}
