package com.example.tfg.Fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tfg.Adapters.AdaptadorHistorial;
import com.example.tfg.Datos.Historial;
import com.example.tfg.R;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class DatosHistorial extends Fragment implements Response.Listener<JSONObject>, Response.ErrorListener {

    View view;
    Button buttonRefresH; // Definimos el botón para refrescar la pestaña

    RecyclerView recyclerHistorial;
    ArrayList<Historial> listHistorial;
    String txtIDB,txtIDD, txtFecha;
    ProgressDialog progreso;

    RequestQueue request;
    JsonObjectRequest jsonObjectRequest;


    public DatosHistorial() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Enlazamos la vista del fragmento
        view = inflater.inflate(R.layout.fragment_datos_historial, container, false);
        //Definimos la instancia del botón refrescar
        buttonRefresH = (Button)view.findViewById(R.id.buttonRefresHist);

        listHistorial = new ArrayList<>();
        //Creamos la vista del recycler
        recyclerHistorial = (RecyclerView) view.findViewById(R.id.recycler_historial);
        recyclerHistorial.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerHistorial.setHasFixedSize(true);

        request = Volley.newRequestQueue(getContext());

        //Al abrir la pestaña, se ejecuta la acción cargarDatos, que nos muestra la lista de bomberos
        cargarDatos();

        //Al pulsar el botón refrescar:
        buttonRefresH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listHistorial.clear(); //Limpiamos los datos de la lista anteriormente cargada
                cargarDatos();        //Cargamos los nuevos datos
            }
        });

        return view;
    }

    //Proceso por el cual se cargan los datos en la listBomberos
    private void cargarDatos() {

        //Generamos un mensaje de progreso de la consulta
        progreso = new ProgressDialog(getContext());
        progreso.setMessage("Consultando BBDD...");
        progreso.show();

        //Definimos la URL del archivo PHP necesario para realizar la consulta a la BBDD
        String url = "http://mo-dep2-d144-09.escet.urjc.es/senialab-iot/consultaHistorial.php";

        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url,null,this,this);
        request.add(jsonObjectRequest);
    }

    // Si falla la petición a la BBDD, se ejecuta el siguiente método
    @Override
    public void onErrorResponse(VolleyError error) {
        //Se cierra el mensaje de "Consultando BBDD..."
        progreso.hide();
        // Abrimos un mensaje toast con el error producido
        Toast.makeText(getContext(), "Error de conexión" + error.toString(), Toast.LENGTH_SHORT).show();
        Log.i("Error", error.toString());
    }

    //Si la petición se ejetuta sin errores, se ejecuta este método
    @Override
    public void onResponse(JSONObject response) {
        //Se cierra el mensaje de "Consultando BBDD..."
        progreso.hide();

        //Mensaje toast de conexión satisfactoria
        Toast.makeText(getContext(), "Conexión establecida", Toast.LENGTH_SHORT).show();

        // Constructor de clase bomberos con sus correspondientes campos
        Historial historial = new Historial(txtIDB, txtIDD, txtFecha);

        //Creación del JSON
        JSONArray json = response.optJSONArray("datos");
        JSONObject jsonObject = null;

        try {
            //Para obtener los datos del JSON
            for (int i = 0; i < json.length(); i++) {
                jsonObject = json.getJSONObject(i);

                //Set de los datos del JSON
                historial.setId_bombero(jsonObject.optString("id_bombero"));
                historial.setid_dispositivo(jsonObject.optString("id_dispositivo"));
                historial.setfecha(jsonObject.optString("fechaRegistro"));

                //Get de los datos del JSON
                txtIDB = historial.getId_bombero();
                txtIDD = historial.getid_dispositivo();
                txtFecha = historial.getfecha();

                //Añadimos los datos obtenidos del JSON a la lista que se va a mostrar en el recycler
                listHistorial.add(new Historial(txtIDB, txtIDD, txtFecha));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        //Mostramos la vista del recycler correspondiente
        AdaptadorHistorial adapter = new AdaptadorHistorial(listHistorial);
        recyclerHistorial.setAdapter(adapter);
    }
}

