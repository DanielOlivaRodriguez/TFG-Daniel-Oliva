package com.example.tfg.Activities;

import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.example.tfg.Fragments.DatosBomberos;
import com.example.tfg.Fragments.DatosHistorial;
import com.example.tfg.Fragments.DatosHistoricosFragment;
import com.example.tfg.Fragments.DatosTrealRecyclerFragment;
import com.example.tfg.Fragments.FisiologicoFragment;
import com.example.tfg.Fragments.FormularioFragment;
import com.example.tfg.Fragments.InfoFragment;
import com.example.tfg.Fragments.MapaBalizasFragment;
import com.example.tfg.Fragments.ModificarBDFragment;
import com.example.tfg.R;

public class MainActivity extends AppCompatActivity {

    /*Definiciones para el menú lateral*/
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    /*Método onCreate*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*Iniciamos en el layout activity main en el que tenemos el menú lateral, la toolbar y
        * el content frame para dibujar encima los Fragments*/
        setContentView(R.layout.activity_main);
        setToolbar();
        /*enlazamos las vistas*/
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        navigationView = (NavigationView) findViewById(R.id.navview);
        /*dibujamos el Fragment por defecto que es el de la primera pestaña*/
        setFragmentByDefault();
        /*configuramos el menú deslizante*/
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                boolean fragmentTransaction = false;
                Fragment fragment = null;

                switch (item.getItemId()) {
                    /*primera pestaña y dibujamos el fragment correspondiente*/
                    case R.id.menu_DatosTreal:
                        fragment = new DatosTrealRecyclerFragment();
                        fragmentTransaction = true;
                        break;
                    /*primera pestaña y dibujamos el fragment correspondiente*/
                    case R.id.menu_DatosHistoricos:
                        fragment = new DatosHistoricosFragment();
                        fragmentTransaction = true;
                        break;
                    /*primera pestaña y dibujamos el fragment correspondiente*/
                    case R.id.menu_Mapa:
                        fragment = new MapaBalizasFragment();
                        fragmentTransaction = true;
                        break;
                    /*primera pestaña y dibujamos el fragment correspondiente*/
                    case R.id.menu_Informacion:
                        fragment = new InfoFragment();
                        fragmentTransaction = true;
                        break;

                    /*primera pestaña y dibujamos el fragment correspondiente*/
                    case R.id.menu_Fisiologico:
                        fragment = new FisiologicoFragment();
                        fragmentTransaction = true;
                        break;
                    /*primera pestaña y dibujamos el fragment correspondiente*/
                    case R.id.menu_Datos:
                        fragment = new DatosBomberos();
                        fragmentTransaction = true;
                        break;

                    case R.id.menu_Modificar:
                        fragment = new ModificarBDFragment();
                        fragmentTransaction = true;
                        break;
                    case R.id.menu_Historial:
                        fragment = new DatosHistorial();
                        fragmentTransaction = true;
                        break;
                    case R.id.menu_Formulario:
                        fragment = new FormularioFragment();
                        fragmentTransaction = true;
                        break;
                }

                if (fragmentTransaction) {
                    changeFragment(fragment, item);
                    drawerLayout.closeDrawers();
                }

                return true;
            }
        });

    }
    /*Toolbar*/
    private void setToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_home);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    /*Fragment que se dibuja por defecto al iniciar la app*/
    private void setFragmentByDefault() {
        changeFragment(new InfoFragment(), navigationView.getMenu().getItem(0));
    }
    /*Método para cambiar de Fragment*/
    private void changeFragment(Fragment fragment, MenuItem item) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.content_frame, fragment)
                .commit();
        item.setChecked(true);
        getSupportActionBar().setTitle(item.getTitle());
    }
    /*Método para saber que pestaña del menú lateral hemos elegido*/
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
            //botón abrir el menú lateral
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
