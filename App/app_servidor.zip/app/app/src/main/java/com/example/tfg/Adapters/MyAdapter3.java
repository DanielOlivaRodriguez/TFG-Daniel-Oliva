package com.example.tfg.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.tfg.Datos.Balizas;
import com.example.tfg.R;

import java.util.List;

/*Este es el adaptador para el RecyclerView de la pestaña Datos en tiempo real*/

public class MyAdapter3 extends RecyclerView.Adapter<MyAdapter3.ViewHolder> {



    /*Definición de variables del constructor*/
    private List<Balizas> balizalist;
    private Context context;

    /*Constructor del adaptador*/
    public MyAdapter3 (Context context, List<Balizas> balizalist) {
        this.context = context;
        this.balizalist = balizalist;
    }
    /*Creación de nuevas vistas*/
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        /*creación de una nueva vista*/
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview3, parent,false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    /*Reemplazar el contenido de una vista (invocado por el Layout Manager)*/
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        /*obtener el elemento del conjunto de datos para esa posición*/
        Balizas balizas = balizalist.get(position);

        /*Reemplazar el contenido de la vista con ese elemento.*/
        holder.textNbalizas.setText("Baliza: "+balizas.getBaliza_id());
        holder.textDist.setText("Distancia: ("+balizas.getDx()+","+balizas.getDy()+") [m]");
    }

    /*Devuelve el tamaño del conjunto de datos (invocado por el Layout Manager)*/
    @Override
    public int getItemCount() {
        return balizalist.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        /*declaración de las vistas del RecyclerView*/
        TextView textNbalizas, textDist;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            /*enlace de las vistas*/
            textNbalizas = itemView.findViewById((R.id.textNBalizaMap));
            textDist = itemView.findViewById(R.id.textDistMap);
        }
    }

}
