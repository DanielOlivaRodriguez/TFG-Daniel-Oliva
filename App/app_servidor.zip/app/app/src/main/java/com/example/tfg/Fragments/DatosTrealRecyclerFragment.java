package com.example.tfg.Fragments;


import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tfg.Datos.Balizas;
import com.example.tfg.Adapters.MyAdapter;
import com.example.tfg.R;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */

/*Fragment para la pestaña Datos en tiempo real*/
public class DatosTrealRecyclerFragment extends Fragment implements Response.Listener<JSONObject>, Response.ErrorListener{
    /*Declaración de variables, contexto, objetos, request, etc*/

    private RecyclerView mReciclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private static Context context =null;

    List<Balizas> balizalist;

    View view;

    TextView textViewhora, textViewNBalizas;
    Button btn_refrescar;
    ProgressDialog progreso;

    RequestQueue request;
    JsonObjectRequest jsonObjectRequest;

    String temperatura,nivelco, hora, balizaid, rssi, fuego, comentario, nBalizas, dx, dy, balizaidB, dxB, dyB;

   /*construtor de la clase*/
    public DatosTrealRecyclerFragment() {

    }

    /*crea y devuelve la jerarquía de vistas asociada con el fragmento*/
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_datos_treal_recycler, container, false);
        /*Como estoy en un Fragment no puedo pasar this y necesito coger el contexto de la actividad*/
        context = getActivity();
        /*enlazo la vista del RecyclerView*/
        mReciclerView = view.findViewById(R.id.reciclerView);
        /*esta configuración mejora el desempeño y se usa cuando el tamaño del RecyclerView no cambia*/
        mReciclerView.setHasFixedSize(true);
        /*Uso de Linear Layout Manager*/
        mLayoutManager = new LinearLayoutManager(getContext());
        mReciclerView.setLayoutManager(mLayoutManager);
        /*creación de un nuevo ArrayList */
        balizalist = new ArrayList<>();
        /*enlazo las vistas y botón*/
        textViewhora = view.findViewById(R.id.textHora2);
        textViewNBalizas = view.findViewById(R.id.NBalizas);
        btn_refrescar = view.findViewById(R.id.btn_refescar2);
        /*Instancia el RequestQuere */
        request = Volley.newRequestQueue(getContext());

        cargarWebService();

        /*Cuando se pulsa el botón refrescar se llama al método cargarWebService y limpia las vistas
        del RecyclerView para que no se acumulen cada vez que pulsamos el botón*/
        btn_refrescar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                balizalist.clear();
                cargarWebService();
            }
        });
        return view;
    }

    /*método que se conecta a la base de datos*/
    private void cargarWebService() {
        /*Mensaje al pulsar el botón*/
        progreso = new ProgressDialog(getContext());
        progreso.setMessage("refrescando...");
        /*abrimos el mensaje de cargando*/
        progreso.show();
        /*URL del archivo PHP que nos devuelve el JSON de los datos pedidos*/
        String url = "https://tfgbomberos.000webhostapp.com/baliza_get.php?n=";
        /*Solicitud para recuperar un JsonObject*/
        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url,null,this,this);
        request.add(jsonObjectRequest);
    }

    /*método si hay un fallo con la petición*/
    @Override
    public void onErrorResponse(VolleyError error) {
        /*cerramos el mensaje de cargando*/
        progreso.hide();
        /*mensaje con error*/
        Toast.makeText(getContext(), "Error de conexión" + error.toString(), Toast.LENGTH_SHORT).show();
        Log.i("Error", error.toString());
    }

    /*método respuesta de la petición*/
    @Override
    public void onResponse(JSONObject response) {
        /*cerramos el mensaje de cargando*/
        progreso.hide();

        /*mensaje toast de conexión realizada*/
        Toast.makeText(getContext(), "Conexión establecida", Toast.LENGTH_SHORT).show();

        /*Llamada al constructor de la clase Balizas*/
        Balizas balizas = new Balizas(hora, temperatura, nivelco, balizaid, rssi, fuego, comentario, nBalizas, dx, dy, balizaidB, dxB, dyB);

        /*creación de un json tipo array*/
        JSONArray json = response.optJSONArray("baliza");

        /*inicialización del jsonOBject*/
        JSONObject jsonObject=null;

        try {
            /*bucle para sacar los datos del json*/
            for ( int i = 0; i < json.length(); i++){
                jsonObject = json.getJSONObject(i);

                /*set de los datos del json*/
                balizas.setBaliza_id(jsonObject.optString("baliza_id"));
                balizas.setTemperatura(jsonObject.optString("temperatura"));
                balizas.setNivelco(jsonObject.optString("nivelco"));

                /*get de los datos del json*/
                temperatura = balizas.getTemperatura();
                balizaid = balizas.getBaliza_id();
                nivelco = balizas.getNivelco();

                /*añadir a la lista balizalist los datos extraídos del json*/
                balizalist.add(new Balizas(hora, temperatura, nivelco, balizaid, rssi, fuego, comentario, nBalizas, dx, dy, balizaidB, dxB, dyB));
            }
            /*Actualizar el campo de texto de hora después de extraer los datos del json de hora*/
            balizas.setHora(jsonObject.optString("hora"));
            hora = balizas.getHora();
            textViewhora.setText("Hora últimos datos: "+hora);

            /*Actualizar el campo de texto de nBalizas después de extraer los datos del json del número de balizas*/
            balizas.setnBalizas(jsonObject.optString("nBalizas"));
            nBalizas = balizas.getnBalizas();
            textViewNBalizas.setText("Número de Balizas: "+nBalizas);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        /*Pasamos el adaptader correspondiente a esta pestaña y mostramos las vistas del reciclerview*/
        MyAdapter adapter = new MyAdapter(getContext(), balizalist);
        mReciclerView.setAdapter(adapter);
    }
}
