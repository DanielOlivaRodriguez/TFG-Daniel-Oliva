package com.example.tfg.Adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.tfg.Datos.Bomberos;
import com.example.tfg.Datos.Historial;
import com.example.tfg.R;
import java.util.List;

public class AdaptadorHistorial extends RecyclerView.Adapter<AdaptadorHistorial.ViewHolder> {

    List<Historial> listHistorial;

    public AdaptadorHistorial(List<Historial> listHistorial) {
        this.listHistorial = listHistorial;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recyclerview_historial, null,false);
        RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        view.setLayoutParams(layoutParams);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.txtIDB.setText(listHistorial.get(i).getId_bombero());
        viewHolder.txtIDD.setText(listHistorial.get(i).getid_dispositivo());
        viewHolder.txtFecha.setText(listHistorial.get(i).getfecha());
    }

    @Override
    public int getItemCount() {
        return listHistorial.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtIDB, txtIDD, txtFecha;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtIDB = (TextView) itemView.findViewById(R.id.tvIDBomberoHistorial);
            txtIDD = (TextView) itemView.findViewById(R.id.tvIDBalizaHistorial);
            txtFecha = (TextView) itemView.findViewById(R.id.tvFechaHist);
        }
    }
}
