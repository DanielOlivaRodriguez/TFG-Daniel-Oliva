package com.example.tfg.Fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tfg.Adapters.AdaptadorBomberos;
import com.example.tfg.Datos.Bomberos;
import com.example.tfg.R;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class DatosBomberos extends Fragment implements Response.Listener<JSONObject>, Response.ErrorListener {

    View view;
    Button buttonRefres; // Definimos el botón para refrescar la pestaña

    RecyclerView recyclerBomberos;
    ArrayList<Bomberos> listBomberos;
    String txtID,txtNombre, txtEdad, txtDispositivo;
    ProgressDialog progreso;

    RequestQueue request;
    JsonObjectRequest jsonObjectRequest;


    public DatosBomberos() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Enlazamos la vista del fragmento
        view = inflater.inflate(R.layout.fragment_datos_bomberos, container, false);
        //Definimos la instancia del botón refrescar
        buttonRefres = (Button)view.findViewById(R.id.buttonRefres);

        listBomberos = new ArrayList<>();
        //Creamos la vista del recycler
        recyclerBomberos = (RecyclerView) view.findViewById(R.id.recycler_bomberos);
        recyclerBomberos.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerBomberos.setHasFixedSize(true);

        request = Volley.newRequestQueue(getContext());

        //Al abrir la pestaña, se ejecuta la acción cargarDatos, que nos muestra la lista de bomberos
        cargarDatos();

        //Al pulsar el botón refrescar:
        buttonRefres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listBomberos.clear(); //Limpiamos los datos de la lista anteriormente cargada
                cargarDatos();        //Cargamos los nuevos datos
            }
        });

        return view;
    }

    //Proceso por el cual se cargan los datos en la listBomberos
    private void cargarDatos() {

        //Generamos un mensaje de progreso de la consulta
        progreso = new ProgressDialog(getContext());
        progreso.setMessage("Consultando BBDD...");
        progreso.show();

        //Definimos la URL del archivo PHP necesario para realizar la consulta a la BBDD
        String url = "http://mo-dep2-d144-09.escet.urjc.es/senialab-iot/consultaLista.php";

        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url,null,this,this);
        request.add(jsonObjectRequest);
    }

    // Si falla la petición a la BBDD, se ejecuta el siguiente método
    @Override
    public void onErrorResponse(VolleyError error) {
        //Se cierra el mensaje de "Consultando BBDD..."
        progreso.hide();
        // Abrimos un mensaje toast con el error producido
        Toast.makeText(getContext(), "Error de conexión" + error.toString(), Toast.LENGTH_SHORT).show();
        Log.i("Error", error.toString());
    }

    //Si la petición se ejetuta sin errores, se ejecuta este método
    @Override
    public void onResponse(JSONObject response) {
        //Se cierra el mensaje de "Consultando BBDD..."
        progreso.hide();

        //Mensaje toast de conexión satisfactoria
        Toast.makeText(getContext(), "Conexión establecida", Toast.LENGTH_SHORT).show();

        // Constructor de clase bomberos con sus correspondientes campos
        Bomberos bomberos = new Bomberos(txtID, txtNombre, txtEdad, txtDispositivo);

        //Creación del JSON
        JSONArray json = response.optJSONArray("datos");
        JSONObject jsonObject = null;

        try {
            //Para obtener los datos del JSON
            for (int i = 0; i < json.length(); i++) {
                jsonObject = json.getJSONObject(i);

                //Set de los datos del JSON
                bomberos.setId_bombero(jsonObject.optString("id_bombero"));
                bomberos.setNombre_apellido(jsonObject.optString("nombre_apellido"));
                bomberos.setEdad(jsonObject.optString("edad"));
                bomberos.setDispositivo_id(jsonObject.optString("dispositivo_id"));

                //Get de los datos del JSON
                txtID = bomberos.getId_bombero();
                txtNombre = bomberos.getNombre_apellido();
                txtEdad = bomberos.getEdad();
                txtDispositivo = bomberos.getDispositivo_id();

                //Añadimos los datos obtenidos del JSON a la lista que se va a mostrar en el recycler
                listBomberos.add(new Bomberos(txtID, txtNombre, txtEdad, txtDispositivo));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        //Mostramos la vista del recycler correspondiente
        AdaptadorBomberos adapter = new AdaptadorBomberos(listBomberos);
        recyclerBomberos.setAdapter(adapter);
    }
}

