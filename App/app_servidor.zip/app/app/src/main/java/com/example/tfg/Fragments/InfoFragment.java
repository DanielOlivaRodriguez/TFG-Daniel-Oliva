package com.example.tfg.Fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.tfg.R;

/**
 * A simple {@link Fragment} subclass.
 */
/*Fragment para la pestaña Información*/
public class InfoFragment extends Fragment {

    /*Constructor de la clase*/
    public InfoFragment() {
        // Required empty public constructor
    }

    /*crea y devuelve la jerarquía de vistas asociada con el fragmento*/
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_info, container, false);
    }

}
