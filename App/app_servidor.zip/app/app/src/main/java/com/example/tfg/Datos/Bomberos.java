package com.example.tfg.Datos;

public class Bomberos {

    //Títulos de las columnas de la BBDD
    private String id_bombero;
    private String nombre_apellido;
    private String edad;
    private String dispositivo_id;

    //Constructor de clase
    public Bomberos(String id_bombero, String nombre_apellido, String edad, String dispositivo_id) {
        this.id_bombero = id_bombero;
        this.nombre_apellido = nombre_apellido;
        this.edad = edad;
        this.dispositivo_id = dispositivo_id;

    }

    public String getId_bombero() {
        return id_bombero;
    }
    public void setId_bombero(String id_bombero) {
        this.id_bombero = id_bombero;
    }

    public String getNombre_apellido() {
        return nombre_apellido;
    }
    public void setNombre_apellido(String nombre_apellido) { this.nombre_apellido = nombre_apellido;}

    public String getEdad() {
        return edad;
    }
    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getDispositivo_id() {
        return dispositivo_id;
    }
    public void setDispositivo_id(String dispositivo_id) {
        this.dispositivo_id = dispositivo_id;
    }

}
