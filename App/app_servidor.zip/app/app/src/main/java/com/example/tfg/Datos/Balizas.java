package com.example.tfg.Datos;
/*clase con métodos get and set para mostrar los datos del Json*/
public class Balizas {
    /*declaraciones de los títulos de cada columna de la base de datos*/
    private String hora;
    private String temperatura;
    private String nivelco;
    private String baliza_id;
    private String rssi;
    private String fuego;
    private String comentario;
    private String nBalizas;
    private String dx;
    private String dy;
    private String baliza_idB;
    private String dxB;
    private String dyB;
/* constructor de la clase Balizas*/
    public Balizas(String hora, String temperatura, String nivelco, String baliza_id, String rssi, String fuego, String comentario, String nBalizas, String dx, String dy, String baliza_idB, String dxB, String dyB) {
        this.hora = hora;
        this.temperatura = temperatura;
        this.nivelco = nivelco;
        this.baliza_id = baliza_id;
        this.rssi = rssi;
        this.fuego = fuego;
        this.comentario = comentario;
        this.nBalizas = nBalizas;
        this.dx = dx;
        this.dy = dy;
        this.baliza_idB = baliza_idB;
        this.dxB = dxB;
        this.dyB = dyB;
    }

    public String getBaliza_idB() {
        return baliza_idB;
    }

    public void setBaliza_idB(String baliza_idB) {
        this.baliza_idB = baliza_idB;
    }

    public String getDxB() {
        return dxB;
    }

    public void setDxB(String dxB) {
        this.dxB = dxB;
    }

    public String getDyB() {
        return dyB;
    }

    public void setDyB(String dyB) {
        this.dyB = dyB;
    }

    public String getDx() {
        return dx;
    }

    public void setDx(String dx) {
        this.dx = dx;
    }

    public String getDy() {
        return dy;
    }

    public void setDy(String dy) {
        this.dy = dy;
    }

    public String getnBalizas() {
        return nBalizas;
    }

    public void setnBalizas(String nBalizas) {
        this.nBalizas = nBalizas;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(String temperatura) {
        this.temperatura = temperatura;
    }

    public String getNivelco() {
        return nivelco;
    }

    public void setNivelco(String nivelco) {
        this.nivelco = nivelco;
    }

    public String getBaliza_id() {
        return baliza_id;
    }

    public void setBaliza_id(String baliza_id) {
        this.baliza_id = baliza_id;
    }

    public String getRssi() {
        return rssi;
    }

    public void setRssi(String rssi) {
        this.rssi = rssi;
    }

    public String getFuego() {
        return fuego;
    }

    public void setFuego(String fuego) {
        this.fuego = fuego;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }
}
