package com.example.tfg.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.tfg.Datos.Balizas;
import com.example.tfg.R;

import java.util.List;

/*Este es el adaptador para el RecyclerView de la pestaña Datos en tiempo real*/

public class MyAdapter2 extends RecyclerView.Adapter<MyAdapter2.ViewHolder> {



    /*Definición de variables del constructor*/
    private List<Balizas> balizalist;
    private Context context;

    /*Constructor del adaptador*/
    public MyAdapter2 (Context context, List<Balizas> balizalist) {
        this.context = context;
        this.balizalist = balizalist;
    }
    /*Creación de nuevas vistas*/
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        /*creación de una nueva vista*/
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview2, parent,false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    /*Reemplazar el contenido de una vista (invocado por el Layout Manager)*/
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        /*obtener el elemento del conjunto de datos para esa posición*/
        Balizas balizas = balizalist.get(position);

        /*Reemplazar el contenido de la vista con ese elemento.*/
        holder.textHora.setText("Hora: "+balizas.getHora());
        holder.textTemp.setText("Temp: "+balizas.getTemperatura()+"ºC");
        holder.textCO.setText("NivCO: "+balizas.getNivelco()+"ppm");
    }

    /*Devuelve el tamaño del conjunto de datos (invocado por el Layout Manager)*/
    @Override
    public int getItemCount() {
        return balizalist.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        /*declaración de las vistas del RecyclerView*/
        TextView textTemp, textCO, textHora;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            /*enlace de las vistas*/
            textHora = itemView.findViewById((R.id.textHora3));
            textTemp = itemView.findViewById(R.id.textTemp2);
            textCO = itemView.findViewById(R.id.textCO2);
        }
    }

}