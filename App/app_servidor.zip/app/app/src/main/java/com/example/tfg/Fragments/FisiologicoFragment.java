package com.example.tfg.Fragments;



import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.tfg.R;


public class FisiologicoFragment extends Fragment {

    public FisiologicoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_fisiologico, container,false);

        WebView webView =(WebView) v.findViewById(R.id.webview);
        //webView.setWebViewClient(new WebViewClient());
        //webView.getSettings().setJavaScriptEnabled(true);

        // Servidor Universidad
        //String url = "http://mo-dep2-d144-09.escet.urjc.es:3000/d/4XZvutZRk/dispositivo-1?orgId=1";
        // Servidor local
        String url = "http://192.168.43.77:3000";


        webView.loadUrl(url);

        return v;
    }

}



