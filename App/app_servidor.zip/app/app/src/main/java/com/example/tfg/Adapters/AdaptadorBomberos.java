package com.example.tfg.Adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.tfg.Datos.Bomberos;
import com.example.tfg.R;
import java.util.List;

public class AdaptadorBomberos extends RecyclerView.Adapter<AdaptadorBomberos.ViewHolder> {

    List<Bomberos> listBomberos;

    public AdaptadorBomberos(List<Bomberos> listBomberos) {
        this.listBomberos = listBomberos;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recyclerview_bomberos, null,false);
        RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        view.setLayoutParams(layoutParams);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.txtID.setText(listBomberos.get(i).getId_bombero());
        viewHolder.txtNombre.setText(listBomberos.get(i).getNombre_apellido());
        viewHolder.txtEdad.setText(listBomberos.get(i).getEdad());
        viewHolder.txtDispositivo.setText(listBomberos.get(i).getDispositivo_id());
    }

    @Override
    public int getItemCount() {
        return listBomberos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtID, txtNombre, txtEdad, txtDispositivo;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtID = (TextView) itemView.findViewById(R.id.tvID);
            txtNombre = (TextView) itemView.findViewById(R.id.tvNombre);
            txtEdad = (TextView) itemView.findViewById(R.id.tvEdad);
            txtDispositivo = (TextView) itemView.findViewById(R.id.tvDispositivo);
        }
    }
}
