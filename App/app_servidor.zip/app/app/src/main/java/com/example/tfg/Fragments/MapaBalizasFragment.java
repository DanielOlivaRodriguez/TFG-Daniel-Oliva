package com.example.tfg.Fragments;


import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.tfg.Adapters.MyAdapter3;
import com.example.tfg.Datos.Balizas;
import com.example.tfg.Datos.Mapas;
import com.example.tfg.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static java.lang.StrictMath.abs;

/**
 * A simple {@link Fragment} subclass.
 */
/*Fragment para la pestaña Mapa Balizas*/
public class MapaBalizasFragment<punto> extends Fragment implements Response.ErrorListener, Response.Listener<JSONObject>{
    /*Declaración de variables, contexto, objetos, request, etc*/

    private static Context context =null;

    View view;

    private RecyclerView rv;
    private RecyclerView.LayoutManager mLayoutManager;

    private Canvas mCanvas;
    private Paint Paint = new Paint();
    private Bitmap mBitmap;
    private ImageView mImageView;

    private Spinner spinner;

    double [][] pc_bombero;
    double [][] pc_baliza;

    //dimensiones sala
    int ancho, alto;
    float x, y, ox,oy;

    float dx1, dy1, aux=0, CoorX, CoorY;
    String nBalizas, rssi, dx, dy, balizaid, hora, temperatura, nivelco, fuego, comentario, balizaidB, dxB, dyB, id, coorX, coorY;

    List<Balizas> balizalist;
    List<Mapas> mapaslist;

    TextView textViewNBalizas, textDistMap1, textNBaliza1;
    Button btn_refrescar;
    ProgressDialog progreso;

    RequestQueue request;
    JsonObjectRequest jsonObjectRequest;

    /*construtor de la clase*/
    public MapaBalizasFragment() {

    }

    /*crea y devuelve la jerarquía de vistas asociada con el fragmento*/
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_mapa_balizas, container, false);

        /*enlazo el spinner*/
        spinner = view.findViewById(R.id.spinner);
        /*enlazo la vista del RecyclerView*/
        rv = view.findViewById(R.id.recyclerViewMap);
        /*Uso de Linear Layout Manager*/
        mLayoutManager = new LinearLayoutManager(getContext());
        rv.setLayoutManager(mLayoutManager);
        rv.setNestedScrollingEnabled(false);
        /*Color del pincel*/
        Paint.setColor(Color.GRAY);
        /*enlazo con la vista*/
        mImageView = view.findViewById(R.id.imageView);
        /*corrección del padding del scrollview*/
        mImageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        mImageView.setAdjustViewBounds(true);
        /*Como estoy en un Fragment no puedo pasar this y necesito coger el contexto de la actividad*/
        context = getActivity();
        /*creación de un nuevo ArrayList */
        balizalist = new ArrayList<>();
        mapaslist = new ArrayList<>();
        /*enlazo las vistas y botón*/
        textViewNBalizas = view.findViewById(R.id.NBalizasMap);
        textNBaliza1 = view.findViewById(R.id.textNBalizaMap1);
        textDistMap1 = view.findViewById(R.id.textDistMap1);
        btn_refrescar = view.findViewById(R.id.btn_refescarMap);
        /*Instancia el RequestQuere */
        request = Volley.newRequestQueue(getContext());
        /*llamada al método cargarWebService que se conecta con la base de datos*/
        cargarWebService();

        /*Cuando se pulsa el botón refrescar se llama al método cargarWebService y limpia las vistas
         * del RecyclerView para que no se acumulen cada vez que pulsamos el botón*/
        btn_refrescar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                balizalist.clear();
                mapaslist.clear();
                cargarWebService();
            }
        });
        return view;
    }


    /*método que se conecta a la base de datos*/
    private void cargarWebService() {
        /*Mensaje al pulsar el botón*/
        progreso = new ProgressDialog(getContext());
        progreso.setMessage("refrescando...");
        /*abrimos el mensaje de cargando*/
        progreso.show();
        /*URL del archivo PHP que nos devuelve el JSON de los datos pedidos*/
        String url = "https://tfgbomberos.000webhostapp.com/mapa.php?n=";
        /*Solicitud para recuperar un JsonObject*/
        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url,null,this,this);
        request.add(jsonObjectRequest);
    }
    /*método fallo con la petición*/
    @Override
    public void onErrorResponse(VolleyError error) {
        /*cerramos el mensaje de cargando*/
        progreso.hide();
        /*mensaje con error*/
        Toast.makeText(getContext(), "Error de conexión" + error.toString(), Toast.LENGTH_SHORT).show();
        Log.i("Error", error.toString());
    }

    /*método respuesta de la petición*/
    @Override
    public void onResponse(JSONObject response) {
        /*cerramos el mensaje de cargando*/
        progreso.hide();

        /*mensaje toast de conexión realizada*/
        Toast.makeText(getContext(), "Conexión establecida", Toast.LENGTH_SHORT).show();

        /*Llamada al constructor de la clase Balizas*/
        Balizas balizas = new Balizas(hora, temperatura, nivelco, balizaid, rssi, fuego, comentario, nBalizas, dx, dy, balizaidB, dxB, dyB);

        /*Llamada al constructor de la clase Mapas*/
        Mapas mapas = new Mapas(id, coorX, coorY);

        /*creación de un json tipo array*/
        JSONArray json = response.optJSONArray("baliza");

        /*inicialización del jsonOBject*/
        JSONObject jsonObject = null;

        try {

            /*bucle para sacar los datos del json*/
            for ( int i = 0; i < json.length(); i++){
                jsonObject = json.getJSONObject(i);

                /*set de los datos del json*/
                balizas.setBaliza_id(jsonObject.optString("baliza_id"));
                balizas.setDx(jsonObject.optString("dx"));
                balizas.setDy(jsonObject.optString("dy"));
                balizas.setBaliza_idB(jsonObject.optString("baliza_idB"));
                balizas.setDxB(jsonObject.optString("dxB"));
                balizas.setDyB(jsonObject.optString("dyB"));
                balizas.setComentario(jsonObject.optString("comentario"));

                /*get de los datos del json*/
                balizaid = balizas.getBaliza_id();
                dx = balizas.getDx();
                dy = balizas.getDy();
                balizaidB = balizas.getBaliza_idB();
                dxB = balizas.getDxB();
                dyB = balizas.getDyB();
                comentario = balizas.getComentario();

                /*añadir a la lista balizalist los datos extraídos del json*/
                balizalist.add(new Balizas(hora, temperatura, nivelco, balizaid, rssi, fuego, comentario, nBalizas, dx, dy, balizaidB, dxB, dyB));
            }
            /*Actualizar el campo de texto de posición de  Bombero y baliza*/
            textNBaliza1.setText("Bombero");
            textDistMap1.setText("Distancia: ("+dxB+","+dyB+") [m]");
            /*Actualizar el campo de texto  de número de balizas después de extraer el dato del json*/
            balizas.setnBalizas(jsonObject.optString("nBalizas"));
            nBalizas = balizas.getnBalizas();
            textViewNBalizas.setText("Número de Balizas: "+nBalizas);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        int itempos = spinner.getSelectedItemPosition();
        /*selección del mapa que hace el usuario a través del spinner, se dibuja dicho mapa y se parsea la imformación del XML de este*/
        parseXML(itempos);
        double [][] map = new double[mapaslist.size()][2];
        for (int i = 0; i < mapaslist.size(); i++) {
            mapas = mapaslist.get(i);

            /*get de los datos del xml*/
            id = mapas.getId();
            coorX = mapas.getCoorX();
            coorY = mapas.getCoorY();

            map[i] = new double[] {Double.parseDouble(coorX), Double.parseDouble(coorY)};
        }
        /*double [][] sotano = new double[9][2];
        sotano[0] = new double[] {1.7, 5};
        sotano[1] = new double[] {1.7, 8.4};
        sotano[2] = new double[] {1.7, 11.4};
        sotano[3] = new double[] {3.8, 5};
        sotano[4] = new double[] {4.55, 8.4};
        sotano[5] = new double[] {4.55, 11.4};
        sotano[6] = new double[] {6.58, 1.94};
        sotano[7] = new double[] {6.58, 8.4};
        sotano[8] = new double[] {6.58, 11.4};*/
        if (aux == 0) {
            ancho = mImageView.getWidth();
            alto = mImageView.getHeight();
            aux++;
        }
        mBitmap = Bitmap.createBitmap(ancho, alto, Bitmap.Config.ARGB_8888);
        mImageView.buildDrawingCache();
        mBitmap = mImageView.getDrawingCache();
        mImageView.setImageBitmap(mBitmap);
        mCanvas = new Canvas(mBitmap);
        /*bucle para sacar los datos de las balizas conectadas y dibujarlas en el mapa*/
        for ( int i = 0; i < balizalist.size(); i++) {
            /*extraigo los datos de la baliza i y los guardo en variables*/
            Balizas balizas1 = balizalist.get(i);
            balizaid = balizas1.getBaliza_id();
            dx1 = Float.parseFloat(balizas1.getDx());
            dy1 = Float.parseFloat(balizas1.getDy());
            comentario = balizas1.getComentario();

            /*convierto las distancias reales en distancia del mapa de la app en función del ancho y largo de la pantalla*/
            dx1 = (dx1+ox) * ancho / x;
            dy1 = (dy1+oy) * alto / y;
            dx1 = ancho - dx1;
            dy1 = alto - dy1;

            /*dibujo un círculo de color cyan donde está la baliza*/
            Paint.setColor(Color.CYAN);
            mCanvas.drawCircle(dx1,dy1,20,Paint);

            /*Dibujo el número de la baliza y el comentario*/
            Paint.setStyle(android.graphics.Paint.Style.FILL);
            Paint.setColor(Color.BLACK);
            Paint.setTextSize(50);
            mCanvas.drawText(balizaid, dx1-12, dy1+14, Paint);
            Paint.setColor(Color.RED);
            Paint.setTextSize(50);
            mCanvas.drawText(comentario, dx1-75, dy1, Paint);
        }
        /*Baliza bombero*/
        /*convierto las distancias reales en distancias de la app en función del ancho y largo de la pantalla*/
        dx1 = Float.parseFloat(dxB);
        dy1 = Float.parseFloat(dyB);
        dx1 = (dx1 + ox) * ancho / x;
        dy1 = (dy1 + oy) * alto / y;
        dx1 = ancho - dx1;
        dy1 = alto - dy1;

        float dxb = dx1;
        float dyb = dy1;

        /*dibujo un círculo de color rojo donde está la baliza*/
        Paint.setColor(Color.RED);
        mCanvas.drawCircle(dx1, dy1, 20, Paint);

        /*Dibujo el texto B de bombero*/
        Paint.setStyle(android.graphics.Paint.Style.FILL);
        Paint.setColor(Color.BLACK);
        Paint.setTextSize(50);
        mCanvas.drawText("B", dx1-12, dy1+14, Paint);

        /*Guiado*/
        double [] my_location = {Float.parseFloat(dxB),Float.parseFloat(dyB)};
        /*Busco el punto de los definidos en el mapa más cercano al bombero*/
        pc_bombero = puntos(map,my_location);
        double [] bomber = pc_bombero [0];
        /*bucle para dibujar parte del guiado del bombero pasando por las balizas, de último número de baliza a primero*/
        for ( int i = balizalist.size()-1; i > -1; i--) {
            /*extraigo los datos de posición de la baliza y los almaceno en variables*/
            Balizas balizas1 = balizalist.get(i);
            dx1 = Float.parseFloat(balizas1.getDx());
            dy1 = Float.parseFloat(balizas1.getDy());
            double [] my_baliza = {dx1,dy1};
            /*Busco el punto de los definidos en el mapa más cercano a la baliza*/
            pc_baliza = puntos(map,my_baliza);
            dx1 = (float) (pc_baliza[0][0]);
            dy1 = (float) (pc_baliza[0][1]);
            /*convierto las distancias reales en distancias de la app en función del ancho y largo de la pantalla*/
            dx1 = (dx1+ox) * ancho / x;
            dy1 = (dy1+oy) * alto / y;
            dx1 = ancho - dx1;
            dy1 = alto - dy1;

            /*dibujo una línea de color negro uniendo la posición dxb y dyb (inicialmente las del bombero, luego se van actualizando
            con el último punto de esta línea) con el último punto de proximidad de la baliza calculado*/
            Paint.setColor(Color.BLACK);
            Paint.setStrokeWidth(10);
            mCanvas.drawLine(dxb,dyb,dxb,dy1, Paint);
            Paint.setColor(Color.BLACK);
            Paint.setStrokeWidth(10);
            mCanvas.drawLine(dxb,dy1,dx1,dy1, Paint);

            /*actualización de las variables dxb y dyb para que en la siguiente iteración dibuje a partir de ellas la línea*/
            dxb = dx1;
            dyb = dy1;
        }
        /*dibujado del guiado final a la posición inicial*/
        /*convierto las distancias reales de la posición inicial en distancias de la app en función del ancho y largo de la pantalla*/
        dx1 = 2*ox * ancho / x;
        dy1 = 2*oy * alto / y;
        dx1 = ancho - dx1;
        dy1 = alto - dy1;

        /*dibujo una línea de color negro uniendo la posición dxb y dyb (actualizada en el bucle con el último punto de proximidad de la baliza calculado)
        * con la posición inicial*/
        Paint.setColor(Color.BLACK);
        Paint.setStrokeWidth(10);
        mCanvas.drawLine(dxb,dyb,dxb,dy1, Paint);
        Paint.setColor(Color.BLACK);
        Paint.setStrokeWidth(10);
        mCanvas.drawLine(dxb,dy1,dx1,dy1, Paint);

        /*for (int i = 0; i<location; i++){
                dx1 = (float) pc_baliza [i][0];
                dy1 = (float) pc_baliza [i][1];
                dx1 = (dx1 + ox) * ancho / x;
                dy1 = (dy1 + oy) * alto / y;

                dx1 = ancho - dx1;
                dy1 = alto - dy1;
                Paint.setColor(Color.BLACK);
                mCanvas.drawCircle(dx1, dy1, 20, Paint);
           }*/
        /*Pasamos el adaptader correspondiente a esta pestaña y mostramos las vistas del reciclerview*/
        MyAdapter3 adapter = new MyAdapter3(getContext(), balizalist);
        rv.setAdapter(adapter);
    }

    /*método que a partir de unos puntos te busca el más cercano*/
    private static double[][] puntos(double [] [] locations, double [] my_location)
    {
        int closest_location = 0;
        double [][] locations1 = locations;
        double [][] locations2 = new double[9][2];
        int aux= 0;
        for(int i = 1; i < locations.length; i++){
            if (getDistance(my_location, locations[closest_location]) > getDistance(my_location, locations[i])){
                closest_location = i;
                locations2[i] = locations1[0];
                locations1[0] = locations[closest_location];
                locations1[closest_location] = locations2[i];
            }}
        for (int i = 0; i<locations.length ; i++){
            for(int j=i+1; j<locations.length;j++) {
                if ((getDistance(my_location, locations1[i]) > getDistance(my_location, locations1[j]))){
                        locations2[i] = locations1[i];
                        locations1[i] = locations1[j];
                        locations1[j] = locations2[i];
                    }}

            }
        return locations1;
    }
    private static int puntos1(double [] [] locations, double [] my_location)
    {
        int closest_location = 0;
        for(int i = 1; i < locations.length; i++){
        if (getDistance(my_location, locations[closest_location]) > getDistance(my_location, locations[i])){
            closest_location = i;
        }}
        return closest_location;

    }

    /*método que te devuelve la distancia entre dos puntos*/
    private static double getDistance(double[] location1, double[]location2){

        return Math.sqrt((location1[0] - location2[0])*(location1[0] - location2[0]) + (location1[1]-location2[1])*(location1[1]-location2[1]));

    }

    /*método para leer xml con datos de los mapas y parsearlo*/
    private void parseXML(int mapa){
        XmlPullParserFactory parserFactory;
        try {
            parserFactory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = parserFactory.newPullParser();
            InputStream is = null;
            if (mapa == 0) {
                is = context.getResources().openRawResource(R.raw.sotano);
                mImageView.setImageResource(R.drawable.t);
                x = (float) 7.37;
                y = (float) 11.9;
                //offset donde empieza bombero
                ox = (float) 0.1;
                oy = (float) 0.1;
            }
            else if (mapa == 1) {
                is = context.getResources().openRawResource(R.raw.planta1);
                mImageView.setImageResource(R.drawable.t1);
                x = (float) 10.1;
                y = (float) 12.1;
                //offset bombero
                ox = (float) 4.3;
                oy = (float) 2.3;
            }
            else if (mapa == 2){
                is = context.getResources().openRawResource(R.raw.brunete);
                mImageView.setImageResource(R.drawable.t2);
                x = (float) 2.37;
                y = (float) 15.2;
                //offset donde empieza bombero
                ox = (float) 0.1;
                oy = (float) 0.1;
            }

            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(is, null);

            processParsing(parser);

        } catch (XmlPullParserException e) {
        } catch (IOException e) {
        }

    }

    /*método para leer xml con datos de los mapas y parsearlo*/
    private void processParsing (XmlPullParser parser) throws IOException, XmlPullParserException {
        int eventType = parser.getEventType();

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String string = null;

            switch (eventType){
                case XmlPullParser.START_TAG:
                    string = parser.getName();

                    if ("id".equals(string)) {
                        id = parser.nextText();
                    }
                    else if ("CoorX".equals(string)){
                        coorX = parser.nextText();
                    }
                    else if ("CoorY".equals(string)) {
                        coorY = parser.nextText();
                        mapaslist.add(new Mapas(id, coorX, coorY));
                    }
                    break;
            }
            eventType = parser.next();
        }

    }

}
