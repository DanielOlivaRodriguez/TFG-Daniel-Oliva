package com.example.tfg.Fragments;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.tfg.R;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;

public class ModificarBDFragment extends Fragment {

    View view;

    Button btnGuardar;
    Button btnBorrar;

    EditText etID, etNombre, etEdad, etDispositivo;


    public ModificarBDFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        // Definimos la vista de los botones y el texto
        view = inflater.inflate(R.layout.fragment_modificar_bd, container, false);

        btnGuardar = (Button)view.findViewById(R.id.btnGuardar);
        btnBorrar = (Button)view.findViewById(R.id.btnBorrar);
        etID = (EditText)view.findViewById(R.id.etID);
        etNombre = (EditText)view.findViewById(R.id.etNombre);
        etEdad = (EditText)view.findViewById(R.id.etEdad);
        etDispositivo = (EditText)view.findViewById(R.id.etDispositivo);

        // Procedimiento que sube los datos introducidos en la app a la BBDD al pulsar el botón guardar
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new CargarDatos().execute("http://mo-dep2-d144-09.escet.urjc.es/senialab-iot/subida.php?id_bombero="+etID.getText().toString()+"&nombre_apellido="+etNombre.getText().toString()+"&edad="+etEdad.getText().toString()+"&dispositivo_id="+etDispositivo.getText().toString());
            }
        });

        // Procedimiento que elimina los datos introducidos en la app de la BBDD al pulsar el botón borrar
        btnBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new CargarDatos().execute("http://mo-dep2-d144-09.escet.urjc.es/senialab-iot/borrado.php?id_bombero="+etID.getText().toString());
            }
        });

        return view;
    }

    private class CargarDatos extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {

            // params comes from the execute() call: params[0] is the url.
            try {
                return downloadUrl(urls[0]);
            } catch (IOException e) {
                return "Error, no se puede acceder a la web";
            }
        }
        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {

            Toast.makeText(getActivity().getApplicationContext(), "Acción ejecutada correctamente", Toast.LENGTH_LONG).show();

        }
    }

    // Este método coge la URL que le hemos pasado anteriormente y la abre. Cogido de la bibliografía de AndroidDeveloper
    private String downloadUrl(String myurl) throws IOException {
        Log.i("URL",""+myurl);
        myurl = myurl.replace(" ","%20");
        InputStream is = null;
        // Only display the first 500 characters of the retrieved
        // web page content.
        int len = 500;

        try {
            URL url = new URL(myurl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000 /* milliseconds */);
            conn.setConnectTimeout(15000 /* milliseconds */);
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            // Starts the query
            conn.connect();
            int response = conn.getResponseCode();
            Log.d("respuesta", "The response is: " + response);
            is = conn.getInputStream();

            // Convert the InputStream into a string
            String contentAsString = readIt(is, len);
            return contentAsString;

            // Makes sure that the InputStream is closed after the app is
            // finished using it.
        } finally {
            if (is != null) {
                is.close();
            }
        }
    }
    // Método necesario para ejecutar el anterior
    public String readIt(InputStream stream, int len) throws IOException, UnsupportedEncodingException {
        Reader reader = null;
        reader = new InputStreamReader(stream, "UTF-8");
        char[] buffer = new char[len];
        reader.read(buffer);
        return new String(buffer);
    }
}
